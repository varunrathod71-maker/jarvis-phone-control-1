package com.varun.jarviscontrol;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 71;
    private EditText commandInput;
    private TextView status;

    @Override public void onCreate(Bundle state) { super.onCreate(state); buildUi(); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 32);
        root.setBackgroundColor(Color.rgb(10,16,28));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S."); title.setTextColor(Color.rgb(90,220,255));
        title.setTextSize(30); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("PHONE CONTROL  •  LOCAL COMMANDS"); subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,8,0,24); root.addView(subtitle);

        Button accessibility = button("1. ENABLE ACCESSIBILITY SERVICE"); root.addView(accessibility);
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        TextView warning = new TextView(this);
        warning.setText("Only enable this service if you understand and trust this app. Commands run when you submit them here.");
        warning.setTextColor(Color.rgb(255,202,110)); warning.setTextSize(13); warning.setPadding(2,12,2,18); root.addView(warning);

        commandInput = new EditText(this);
        commandInput.setMinLines(2); commandInput.setHint("Try: home, back, notifications, quick settings, open YouTube");
        commandInput.setHintTextColor(Color.GRAY); commandInput.setTextColor(Color.WHITE);
        commandInput.setPadding(16,14,16,14); commandInput.setBackgroundColor(Color.rgb(28,38,56)); root.addView(commandInput);

        Button voice = button("🎙 SPEAK COMMAND"); root.addView(voice); voice.setOnClickListener(v -> listen());
        Button run = button("▶ RUN COMMAND"); root.addView(run); run.setOnClickListener(v -> runCommand(commandInput.getText().toString()));
        Button home = button("HOME"); root.addView(home); home.setOnClickListener(v -> runCommand("home"));
        Button back = button("BACK"); root.addView(back); back.setOnClickListener(v -> runCommand("back"));
        Button notifications = button("OPEN NOTIFICATIONS"); root.addView(notifications); notifications.setOnClickListener(v -> runCommand("notifications"));
        Button quick = button("QUICK SETTINGS"); root.addView(quick); quick.setOnClickListener(v -> runCommand("quick settings"));

        status = new TextView(this); status.setText("Ready. Enable the service, then submit a command.");
        status.setTextColor(Color.rgb(170,220,190)); status.setTextSize(14); status.setPadding(0,22,0,10); root.addView(status);
        setContentView(scroll);
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(14);
        b.setPadding(8,12,8,12);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(24,94,125)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,6,0,6); b.setLayoutParams(lp);
        return b;
    }

    private void listen() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a phone command");
            startActivityForResult(i, SPEECH_REQUEST);
        } catch (Exception e) { status.setText("Voice input unavailable; type a command instead."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { commandInput.setText(results.get(0)); runCommand(results.get(0)); }
        }
    }

    private void runCommand(String raw) {
        String cmd = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        if (cmd.isEmpty()) { status.setText("Type or speak a command first."); return; }
        JarvisAccessibilityService service = JarvisAccessibilityService.getInstance();
        if (service == null) { status.setText("Service isn't enabled. Tap enable, switch JARVIS Phone Control on, then return."); return; }
        boolean ok = service.executeCommand(cmd);
        status.setText(ok ? "Command sent: " + cmd : "Unknown command. Try home, back, notifications, quick settings, or open YouTube.");
    }
}
