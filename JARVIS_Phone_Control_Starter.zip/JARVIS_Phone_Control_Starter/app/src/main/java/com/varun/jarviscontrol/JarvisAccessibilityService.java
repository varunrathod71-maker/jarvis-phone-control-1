package com.varun.jarviscontrol;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.view.accessibility.AccessibilityEvent;
import java.util.Locale;

public class JarvisAccessibilityService extends AccessibilityService {
    private static volatile JarvisAccessibilityService instance;
    public static JarvisAccessibilityService getInstance() { return instance; }
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public boolean executeCommand(String raw) {
        if (raw == null) return false;
        String cmd = raw.trim().toLowerCase(Locale.ROOT);
        switch (cmd) {
            case "home": case "go home": case "press home": return performGlobalAction(GLOBAL_ACTION_HOME);
            case "back": case "go back": case "press back": return performGlobalAction(GLOBAL_ACTION_BACK);
            case "notifications": case "open notifications": case "show notifications": return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            case "quick settings": case "open quick settings": return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
            case "lock screen": return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
            case "open youtube": case "youtube": return openUrl("https://www.youtube.com");
            case "open google": case "google": return openUrl("https://www.google.com");
            case "open chrome": case "chrome": return launchPackage("com.android.chrome");
            case "open settings": case "settings": return openSettings();
            default:
                if (cmd.startsWith("open https://") || cmd.startsWith("open http://")) return openUrl(cmd.substring(5).trim());
                return false;
        }
    }
    private boolean openUrl(String url) {
        try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
        catch (Exception e) { return false; }
    }
    private boolean launchPackage(String packageName) {
        try { Intent i = getPackageManager().getLaunchIntentForPackage(packageName); if (i == null) return false; i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
        catch (Exception e) { return false; }
    }
    private boolean openSettings() {
        try { Intent i = new Intent(android.provider.Settings.ACTION_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
        catch (Exception e) { return false; }
    }
}
