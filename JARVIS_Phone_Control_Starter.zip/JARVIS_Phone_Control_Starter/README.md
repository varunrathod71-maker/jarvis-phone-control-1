# JARVIS Phone Control — starter Android project

A minimal native Android starter project for explicit, user-submitted phone commands.

## Included
- Voice dictation through Android's speech-recognition activity (if available).
- Home, Back, Notifications, Quick Settings, and Lock Screen global actions.
- Open YouTube, Google, Chrome, and Android Settings.
- Open an `http://` or `https://` URL with a command such as `open https://example.com`.

## Limitations
- This is source code, not a prebuilt APK.
- Accessibility Service must be enabled manually in Android Settings.
- It does not silently monitor screens, read screen contents, or tap arbitrary controls.
- Android/OEM policies may restrict some global actions. Lock Screen may not work on every device/version.
- Opening Chrome assumes package name `com.android.chrome`; using an `open https://...` command is a fallback.
- No cloud AI, API key, or connection to the existing JARVIS website is included yet.
- Test before relying on it.

## Build
Open this folder in an Android IDE that supports Gradle projects. The first build may need internet access to download Gradle/Android Gradle Plugin and Android SDK components. Uses Android Gradle Plugin 8.7.3, compile SDK 35, minimum Android 8.
